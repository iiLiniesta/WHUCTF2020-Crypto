from Crypto.Cipher import AES
import base64

from leaked_secret import key
from secret import IV, AES_KEYSIZE

assert len(key) == AES_KEYSIZE


def aes_pad(s):
    t = bytes((AES_KEYSIZE - len(s) % AES_KEYSIZE) * chr(AES_KEYSIZE - len(s) % AES_KEYSIZE),
              encoding='utf-8')
    return s + t


def enc():
    f = open('plaintext', 'r')
    plaintext = f.readlines()
    f.close()
    f = open('ciphertext', 'w')
    for i in range(len(IV)):
        aes = AES.new(key, AES.MODE_CBC, IV[i])
        m = aes_pad(base64.b64decode(plaintext[i]))
        cipher = aes.encrypt(m)
        print(bytes.decode(base64.b64encode(cipher)), file=f)
    f.close()


if __name__ == '__main__':
    enc()
