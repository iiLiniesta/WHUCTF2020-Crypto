from Crypto.Util.number import getPrime, getRandomInteger, long_to_bytes, bytes_to_long
import gmpy2
import hashlib

from secret import K


def H1(name):
    ans = b''
    ans += hashlib.sha512(name.encode('utf-8')).digest()
    while len(ans) * 8 < K:
        ans += hashlib.sha512(ans).digest()
    return bytes_to_long(ans[:K])


def H2(x):
    ans = b''
    b = long_to_bytes(x, K // 8)
    now = 0
    while now * 8 < K:
        ans += hashlib.sha512(b[now:min(now + 64, len(b) - 1)]).digest()
        now = len(ans)
    return ans[:K]


def bilinear(x, y, g, N):
    return pow(g, x * y, N)


def setup():
    p = getPrime(K // 2)
    q = getPrime(K // 2)
    N = p * q
    phi = (p - 1) * (q - 1)
    P = 0
    while gmpy2.gcd(P, phi) != 1 or P > phi:
        P = gmpy2.next_prime(getRandomInteger(K) % phi)
    g = 0
    while gmpy2.gcd(g, phi) != 1 or gmpy2.gcd(g, N) != 1:
        g = getPrime(K // 2)
    s = getRandomInteger(K) % phi
    P_pub = s * P % phi
    params = N, P, P_pub, g
    master_key = s, phi
    return params, master_key


def extract(ID, params, master_key):
    N, P, P_pub, g = params
    s, phi = master_key
    assert len(ID) * 8 <= K
    Q_ID = H1(ID)
    d_ID = s * Q_ID % phi
    return d_ID


def encrypt(m, ID, params):
    N, P, P_pub, g = params
    assert len(ID) * 8 <= K
    Q_ID = H1(ID)
    r = getRandomInteger(K)
    U = pow(g, r * P, N)
    g_ID = bilinear(Q_ID, P_pub, g, N)
    V = bytes_to_long(H2(pow(g_ID, r, N))) ^ bytes_to_long(m)
    c = U, V
    return c
