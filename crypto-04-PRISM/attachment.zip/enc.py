from Crypto.Util.number import getRandomInteger
import gmpy2


def enc(keys, m):
    p, g, y = keys[-1]
    while True:
        k = getRandomInteger(2048)
        if gmpy2.gcd(k, p-1) == 1:
            break
    c1 = pow(g, k, p)
    m = (getRandomInteger(64) << m.bit_length()) + m
    m = ((m << 64) + getRandomInteger(64))
    c2 = pow(y, k, p) * m % p
    return c1, c2
