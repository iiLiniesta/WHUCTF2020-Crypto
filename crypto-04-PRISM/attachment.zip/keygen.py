from Crypto.Util.number import getPrime, getRandomInteger, long_to_bytes, bytes_to_long
from Crypto.Cipher import AES
from Crypto.Util import Counter
import gmpy2

from secret import rsa_keygen


def FFF(food, key):
    K = 0xe238c70fe2d1885a1b12debfa15484cab8af04675c39ff4c633d6177f234ed88
    key = long_to_bytes(key, 32)
    food = long_to_bytes(food, 128)
    aes = AES.new(key, AES.MODE_CTR, counter=Counter.new(128, initial_value=K))
    c = bytes_to_long(aes.encrypt(food))
    return c
    

def GGG(food, key):
    K = 0xfd94d8de73e4aa8f4f452782b98a7870e82ec92a9db606fe4ca41f32d6df90c5
    K = long_to_bytes(K, 32)
    food = long_to_bytes(food, 128)
    aes = AES.new(K, AES.MODE_CTR, counter=Counter.new(128, initial_value=key))
    c = bytes_to_long(aes.encrypt(food))
    return c
    

def keygen():
    keys = []
    
    n0, e0 = rsa_keygen()
    keys.append([n0, e0])
    N0, E0 = n0, e0
    
    while True:
        p1 = getPrime(1024 // 2)
        e1 = pow(p1, E0, N0)
        q1 = getPrime(1024 // 2)
        n1 = p1 * q1
        phi1 = (p1-1)*(q1-1)
        if e1 < n1 and gmpy2.gcd(e1, phi1) == 1:
            break
    keys.append([n1, e1])
    N1, E1 = n1, e1

    K2 = 0xb6a022cd2fb960d4b6caa601a0412918fd80656b76c782fa6fe9cf50ef205ffb
    B2_1 = 8
    B2_2 = 8
    B2_3 = 1024
    while True:
        p2 = getPrime(2048 // 2)
        i = 0
        while True:
            p2_1 = FFF(p2, K2 + i)
            if p2_1 < N1:
                break
            i += 1
            if i >= B2_1:
                break
        if i >= B2_1:
            continue
        p2_2 = pow(p2_1, E1, N1)
        j = 0
        while True:
            p2_3 = GGG(p2_2, K2 + j)
            x2 = (p2_3 << 1024) + getRandomInteger(1024)
            q2 = gmpy2.next_prime(x2 // p2)
            n2 = p2 * q2
            if 0 <= (n2 >> 1024) - p2_3 < B2_3:
                break
            j += 1
            if j >= B2_2:
                break
        if i <= B2_1 and j < B2_2:
            break
    e2 = 65537
    keys.append([n2, e2])
    N2, E2 = n2, e2

    K3 = 0xfcec710a0313bb8f93e76e00ae6862b9be72dfd837db3b64ddde344bebfd2f50
    B3_1 = 8
    B3_2 = 1024
    while True:
        x3 = gmpy2.next_prime(getRandomInteger(2048) % N2)
        if x3 >= N2:
            continue
        x3_2 = pow(x3, E2, N2)
        i = 0
        while True:
            f3 = FFF(x3_2, K3 + i)
            p3 = gmpy2.next_prime(f3)
            if p3 > x3 and p3 - f3 < B3_2:
                break
            i += 1
            if i >= B3_1:
                break
        if i < B3_1:
            break
    while True:
        g3 = gmpy2.next_prime(getRandomInteger(p3.bit_length()) % p3)
        if g3 < p3 and 1 == gmpy2.gcd(g3, p3-1):
            break
    y3 = pow(g3, x3, p3)
    keys.append((p3, g3, y3))
    P3, G3, Y3 = p3, g3, y3

    B4 = 16384
    while True:
        x4 = gmpy2.next_prime(getRandomInteger(2048) % P3)
        k = getPrime(2048)
        if x4 >= P3 or gmpy2.gcd(k, P3-1) > 1:
            continue
        b4 = pow(Y3, k, P3) * x4 % P3
        p4 = gmpy2.next_prime(b4)
        g4 = pow(G3, k, P3)
        if gmpy2.is_prime(p4) and x4 < p4 and g4 < p4 and p4 - b4 < B4:
            break
    y4 = pow(g4, x4, p4)
    keys.append([p4, g4, y4])
    
    return keys

